var mongoose = require('mongoose');

var instructorSchema = new mongoose.Schema({
  firstName: {type: String, required: true},
  lastName: {type: String, required: true},
  calendars: [{
  	type: mongoose.Schema.ObjectId,
  	ref: 'calendars'
  }]
});

module.exports = mongoose.model('instructors', instructorSchema);