var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var instructorSchema = require('../MongoModels/instructors.js');

/*GET all instructors*/
router.get('/', function(req, res){
	instructorSchema.find(function(err, data){
		if(err){
			console.log('error getting instructors: '+err)
			return err;
		}
		res.json(data);
	});
});

/*POST a new instructor document*/
router.post('/', function(req, res){
	res.json({"post": req.body});
});

/*PUT (edit) a single instructor document*/
router.put('/:Iid', function(req, res){
	var Iid = req.params.Iid;
	res.json({"put": Iid});
});

/*DELETE a single instructor document*/
router.delete('/:Iid', function(req, res){
	var Iid = req.params.Iid;
	res.json({"delete": Iid});
});

module.exports = router;
